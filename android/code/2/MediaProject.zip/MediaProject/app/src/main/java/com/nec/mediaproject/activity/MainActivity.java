package com.nec.mediaproject.activity;

import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.media.SoundPool;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.nec.mediaproject.R;
import com.nec.mediaproject.base.BaseActivity;

import java.io.IOException;

public class MainActivity extends BaseActivity {
    private TextView mediarecorder_tv;
    private TextView soundpool_tv;
    private TextView ringtone_tv;
    private TextView mediaplayer_tv;
    private TextView audiorecord_tv;
    private TextView mediplayer_tv;
    private TextView videoview_tv;

    //设置布局文件
    @Override
    protected void setWindowView() {
        setContentView(R.layout.activity_main);
    }

    //初始化控件
    @Override
    protected void initViews() {
        this.mediarecorder_tv = findViewById(R.id.mediarecorder_tv);
        this.soundpool_tv = findViewById(R.id.soundpool_tv);
        this.ringtone_tv = findViewById(R.id.ringtone_tv);
        this.mediaplayer_tv = findViewById(R.id.mediaplayer_tv);
        this.audiorecord_tv = findViewById(R.id.audiorecord_tv);
        this.mediplayer_tv = findViewById(R.id.mediplayer_tv);
        this.videoview_tv = findViewById(R.id.videoview_tv);
    }

    //为控件设置事件监听
    @Override
    protected void initEvents() {
        this.soundpool_tv.setOnClickListener(this);
        this.mediarecorder_tv.setOnClickListener(this);
        this.ringtone_tv.setOnClickListener(this);
        this.mediaplayer_tv.setOnClickListener(this);
        this.audiorecord_tv.setOnClickListener(this);
        this.mediplayer_tv.setOnClickListener(this);
        this.videoview_tv.setOnClickListener(this);
    }

    //点击事件的回调函数
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.soundpool_tv://soundPool
                soundPoolPlay();
                break;
            case R.id.ringtone_tv://ringtone,系统提示音
                //RingtoneManager
                playRingtoneDefault();
                break;
            case R.id.mediaplayer_tv://mediaplayer 状态图
                //idle、intialized、prepared、started、stoped、paused..
                mediaPlayer();
                break;
            case R.id.mediarecorder_tv://录音
                startActivity(this, MediaRecorderActivity.class);
                break;
            case R.id.audiorecord_tv://audioTrack的使用
                //audioTrack：PCM音频格式的播放
                //界面跳转
                startActivity(this, AudioRecordActivity.class);
                break;
            case R.id.mediplayer_tv://MediaPlayer + SurfaceView
                startActivity(this, VideoPlayActivity.class);
                break;
            case R.id.videoview_tv:
                startActivity(this, VideoViewActivity.class);
                break;
            default:
                break;
        }
    }

    private void mediaPlayer() {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.tonghua);
        //一定要加
        if(mp!= null){
            mp.stop();
        }
        try {
            mp.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        mp.start();
    }

    private void playRingtoneDefault() {
        Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        Ringtone mRingtone = RingtoneManager.getRingtone(this, uri);
        mRingtone.play();
    }

    private void soundPoolPlay() {
        AudioAttributes abs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
        final SoundPool mSoundPool = new SoundPool.Builder()
                .setMaxStreams(10)   //设置允许同时播放的流的最大值
                .setAudioAttributes(abs)   //完全可以设置为null
                .build();
        //load加载资源
        final int id = mSoundPool.load(this, R.raw.alipay, 5);
        //通过回调来进行音频的播放
        mSoundPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
            @Override
            public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
                mSoundPool.play(id, 1, 1, 5, -1, 1);
                Log.i("TAG", "sound pool");
            }
        });
    }
}
