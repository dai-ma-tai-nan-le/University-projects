## 2、Android音视频播放

**@author：于洪伟**



### 2.1、使用SoundPool播放音频

SoundPool支持多个音频文件同时播放(组合音频也是有上限的)，延时短，比较适合短促、密集的场景，是游戏开发中音效播放的福音。

#### 2.1.1、SoundPool实例化方式

* new SoundPool

  该方式适用于5.0以下，从android5.0开始此方法被标记为过时。主要的参数含义为：

  * maxStreams :允许同时播放的流的最大值。
  * streamType ：音频流的类型描述，在Audiomanager中有种类型声明，游戏应用通常会使用流媒体音乐AudioManager.STREAM_MUSIC
  * srcQuality：采样率转化质量，默认值为0 。

* SoundPool.Builder：内部类的方式，Builder：构建器。

  常见的**设计模式：**

  * 在软件开发当中，人们将一些固定的，经典的代码的实现方式，固定下来，形成一套规范和规则，供大家学习和使用，这种软件发展的过程中积累下的固定的形式，称之为设计模式。
    * 盖房子：
      * 四间大瓦房
      * 四间二层小楼，全是平房
      * 三件瓦房，一间二层平房
      * ...
  
  * Builder是一种设计模式。
  * 单例模式：new对象，单例模式全局只有一个对象实例。
  * 工厂模式：专门用于创建对象的类，功能比较单一。
  * 观察者模式：需要时刻关注某个实例的变化
  * ...
  
  从5.0开始支持Builder模式进行对象实例化。主要使用步骤为：
  
  ```java
   AudioAttributes abs = new AudioAttributes.Builder()
                      .setUsage(AudioAttributes.USAGE_MEDIA)
                      .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                      .build() ;
  SoundPool mSoundPoll =  new SoundPool.Builder()
    .setMaxStreams(10)   //设置允许同时播放的流的最大值
    .setAudioAttributes(abs)   //完全可以设置为null
    .build() ;
  ```

#### 2.1.2、SoundPool的几个重要的方法

* pause(int streamID）：通过流id暂停播放
* play(int soundID, float leftVolume, float rightVolume, int priority, int loop, float rate)：该方法会返回一个streamID,如果StreamID为0表示播放失败，否则为播放成功。参数含义如下所示：
  * soundID：音频id
  * left/rightVolume：左右声道，默认1,1；
  * loop：循环次数，-1无限循环，0代表不循环
  * rate：播放速率，1为标准
* release：释放资源，这一步很重要，在使用完相应的控制器资源后，都要释放。
* resume(int streamID)：恢复播放，通过ID来指定恢复的音频。
* setLoop(int streamID, int loop)：设置指定id的音频循环播放次数。
* setPriority(int streamID, int priority)：设置优先级(同时播放个数超过最大值时，优先级低的先被移除)。
* stop(int streamID)：停止指定音频播放。

#### 2.1.3、SoundPool的注意事项

使用SoundPool把一段音频加载到内存在还需要一段时间，所以如果在Load方法后立即调用play，可能会播放不成功。解决方法是需要等待音频加载完毕后再开始播放，通常的解决方法：

* 先执行load加载，通过用户操作开始播放；通常是按钮。

* 设置OnLoadCompleteListener监听。比如：

  ```java
  SoundPool soundPool=new  SoundPool(100,AudioManager.STREAM_MUSIC,5);//构建对象
      soundPool.setOnLoadCompleteListener(new OnLoadCompleteListener() {
              @Override
              public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
                   soundPool.play(sampleId,1,1,1,0,1);//播放
              }
          });
  soundPool.load(this,R.raw.victory,1);//加载资源
  ```



### 2.2、使用Ringtone播放音频

Ringtone为铃声、通知和其他类似声音提供快速播放的方法,这里还不得不提到一个管理类”RingtoneManager”，提供系统铃声列表检索方法，并且，Ringtone实例需要从RingtoneManager获取。

#### 2.2.1、获取Ringtone实例

```java
//1、通过铃声uri获取
static Ringtone getRingtone(Context context, Uri ringtoneUri);
//2、通过铃声检索位置获取
Ringtone getRingtone(int position)
```

#### 2.2.2、RingtoneManager的几个重要的方法

```java
//两个构造方法
RingtoneManager(Activity activity)
RingtoneManager(Context context)
  
//获取指定声音类型(铃声、通知、闹铃等)的默认声音的Uri
static Uri getDefaultUri(int type)
  
//获取系统所有Ringtone的cursor，数据库游标，常用此方法。
Cursor getCursor()
  
//获取cursor指定位置的Ringtone uri
Uri getRingtoneUri(int position)//该下标从0开始
  
//判断指定Uri是否为默认铃声
static boolean isDefault(Uri ringtoneUri)
 
//获取指定uri的所属类型
static int getDefaultType(Uri defaultRingtoneUri)
  
//将指定Uri设置为指定声音类型的默认声音
static void setActualDefaultRingtoneUri(Context context, int type, Uri ringtoneUri)
```

#### 2.2.3、Ringtone的使用场景

Ringtone和RingtoneManager比较简单，此处展示如下案例。

```java
/**
 * 播放来电铃声的默认音乐
*/
private void playRingtoneDefault(){
    Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE) ;
    Ringtone mRingtone = RingtoneManager.getRingtone(this,uri);
    mRingtone.play();
}

/**
* 随机播放一个Ringtone(有可能是提示音、铃声等)
*/
private void ShufflePlayback(){
    RingtoneManager manager = new RingtoneManager(this) ;
    Cursor cursor = manager.getCursor();//获取到说有的提示音
    int count = cursor.getCount() ;//获取到提示音的个数
    int position = (int)(Math.random()*count) ;
    Ringtone mRingtone = manager.getRingtone(position);
    mRingtone.play();
}
```

#### 2.2.4、使用注意事项

Rington这个类比较简单，只需要掌握，播放、停止(paly(),stop())等方法就可以了，而RingtoneManager却是比较重要的。只是在使用该API时，不要忘记在AndroidManifest.xml中申请权限。

```java
<uses-permission android:name="android.permission.MEDIA_CONTENT_CONTROL"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
```



### 2.3、MediaPlayer播放音频

Android多媒体中最常用的音视频播放类是**MediaPlayer**，我们可以通过这个API来播放音频和视频。该类是Androd多媒体框架中的一个重要组件，通过该类，我们可以以最小的步骤来获取，解码和播放音视频。它支持三种不同的媒体来源：

* 本地资源
* 内部的URI，比如你可以通过ContentResolver来获取
* 外部URL(流) 对于Android所支持的的媒体格式列表，通常主要指的是网络资源

* 2.1.1、获得MediaPlayer实例

  ```java
  MediaPlayer mp = new MediaPlayer();
  MediaPlayer mp = MediaPlayer.create(this, R.raw.test);  //无需再调用setDataSource
  ```

* 2.1.2、设置播放文件

  ```java
  //①raw下的资源：
  MediaPlayer.create(this, R.raw.test);
  
  //②本地文件路径：
  mp.setDataSource("/sdcard/test.mp3");
  
  //③网络URL文件：
  mp.setDataSource("http://www.xxx.com/music/test.mp3");
  ```

  setDataSource()方法有多个，里面有这样一个类型的参数：FileDescriptor，在使用这个 API的时候，需要把文件放到res文件夹平级的assets文件夹里，然后使用下述代码设置DataSource：

  ```java
  AssetFileDescriptor fileDescriptor = getAssets().openFd("rain.mp3");
  m_mediaPlayer.setDataSource(fileDescriptor.getFileDescriptor(),fileDescriptor.getStartOffset(), fileDescriptor.getLength());
  ```

* 2.1.3、其他方法
  * getCurrentPosition：得到当前的播放位置
  * getDuration：得到文件的时间
  * isLooping：是否循环播放
  * isPlaying：是否正在播放
  * pause：暂停
  * prepare：准备资源（同步方法）
    * 同步：两件事，先做A，后做B，B要等A做完以后再开始做
    * 异步：两件事，先做A，A做的过程中，开始做B，不需要等待A做完
  * release：释放MediaPlayer对象
  * reset：重置MediaPlayer对象
  * **seekTo(int msec)：**指定播放的位置（以毫秒为单位的时间）
  * setAudioStreamType（int streemtype）：指定流媒体的类型
  * **setLooping（boolean）：**设置是否循环播放
  * start()：开始播放
  * stop()：停止播放
  
* 2.1.4、MediaPlayer状态图管理

  <img src="./img/WX20220309-155058@2x.png" style="zoom:80%;" />



### 2.4、使用AudioTrack播放音频

AudioTrack属于更偏底层的音频播放，MediaPlayerService的内部就是使用了AudioTrack。

AudioTrack用于单个音频播放和管理，相比于MediaPlayer具有：精炼、高效的优点。更适合实时产生播放数据的情况，比如加密的音频，MediaPlayer无法播放，AudioTrack却可以。

AudioTrack用于播放**PCM(PCM无压缩的音频格式)音乐流**的回放，如果要播需放其它格式音频，需要响应的解码器，这也是AudioTrack用的比较少的原因，需要自己解码音频。关于音频编解码，后文会专门介绍。

PCM是一种音频的文件格式，PCM是原始的音频格式，是无压缩。

为什么要压缩？节省空间

AudioTreack的2种播放模式：

* static：静态模式，静态的言下之意就是数据一次性交付给接收方。好处是简单高效，只需要进行一次操作就完成了数据的传递;缺点当然也很明显，对于数据量较大的音频回放，显然它是无法胜任的，因而通常只用于播放铃声、系统提醒等对内存小的操作。

* streaming：数据流模式。流模式和网络上播放视频是类似的，即数据是按照一定规律不断地传递给接收方的。理论上它可用于任何音频播放的场景，通常使用streaming模式的情况是：

  * 音频文件过大
  * 音频属性要求高，比如采样率高、深度大的数据
  * 音频数据是实时产生的，这种情况只能用流模式

  

通过write(byte[], int, int), write(short[], int, int)等方法推送解码数据到AudioTrack，后文会继续学习。



### 2.5、音频播放总结

* 对于延迟度要求不高，并且希望能够更全面的控制音乐的播放，MediaPlayer比较适合。
* 声音短小，延迟度小，并且需要几种声音同时播放的场景，适合使用SoundPool。
* 播放大文件音乐，如PCM无压缩音频，可使用更底层的播放方式AudioTrack。它支持流式播放，可以读取(可来自本地和网络)音频流，播放延迟较小。
* 对于系统类声音的播放和操作，Ringtone更适合。



### 2.6、AudioRecord采集声音

* AudioRecord 类的主要功能是让各种应用层应用能够管理音频资源，以便它们通过此类能够录制平台的声音输入硬件所收集的声音。在录音过程中，应用所需要做的就是通过read方法去及时地获取 AudioRecord 对象的录音数据。
* AudioRecord可以获取到一帧帧PCM数据，之后可以对这些数据进行处理。AudioRecord这种方式采集最为灵活，使开发者最大限度的处理采集的音频,同时它捕获到的音频是原始音频PCM格式的！

#### 2.6.1、声音采集流程

开始录音时，一个 AudioRecord 需要初始化一个相关联的声音buffer，该 buffer 主要是用来保存新的声音数据。这个 buffer 的大小，我们可以在对象构造期间去指定。它表明一个 AudioRecord 对象还没有被读取（同步）声音数据前能录多长的音(即一次可以录制的声音容量)。声音数据从音频硬件中被读出，数据大小不超过整个录音数据的大小（可以分多次读出），即每次读取初始化 buffer 容量的数据。

AudioRecord使用流程如下：

* 1、配置参数，主要包括：

  - audioResource音频采集的来源：可以是麦克风声音、通话声音、系统内置声音。
  - audioSampleRate音频采样率
  - channelConfig声道：单声道、双声道等
  - audioFormat:音频采样精度，指定采样的数据的格式和每次采样的大小，只支持8位和16位。
  - buffer缓冲区大小:音频数据写入缓冲区的总数，可以通过AudioRecord.getMinBufferSize获取最小的缓冲区。获取最小的缓冲区大小，用于存放AudioRecord采集到的音频数据。

* 2、初始化一个buffer，该buffer大于等于AudioRecord对象用于写声音数据的buffer大小`byte data[] = new byte[recordBufSize];`

* 3、获得AudioRecord对象：

  ```java
  public AudioRecord(int audioSource, int sampleRateInHz, int channelConfig, int audioFormat, int bufferSizeInBytes)
  ```

*  4、声音采集录制操作
  
  * 开始录制：`startRecording()`
  * 停止录制`stop()`
  * 释放资源`release()`
  * 使用`read()`来读取采集到的音频数据
* 5、建一个数据流，一边从AudioRecord中读取声音数据到初始化的buffer，一边将buffer中的数据导入数据流
* 6、关闭数据流
* 7、停止录制

#### 2.6.2、示例如下

```java
private AudioRecord audioRecord = null;  // 声明 AudioRecord 对象private int recordBufSize = 0; // 声明recoordBufffer的大小字段

recordBufSize = AudioRecord.getMinBufferSize(frequency, channelConfiguration, EncodingBitRate);  //audioRecord能接受的最小的buffer大小
  audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, frequency, channelConfiguration, EncodingBitRate, recordBufSize); //创建audiorecord对象
  
byte data[] = new byte[recordBufSize];      //初始化一个buffer

audioRecord.startRecording(); //开始录音

//创建一个数据流，一边从AudioRecord中读取声音数据到初始化的buffer，一边将buffer中数据导入数据流。
FileOutputStream os = null;

try {
   os = new FileOutputStream(filename);
} catch (FileNotFoundException e) {
   e.printStackTrace();
}
if (null != os) {    
while (isRecording) {        
read = audioRecord.read(data, 0, recordBufSize);　　　　  // 如果读取音频数据没有出现错误，就将数据写入到文件        if (AudioRecord.ERROR_INVALID_OPERATION != read) {            try {                
os.write(data);            
} catch (IOException e) {               
e.printStackTrace();          
}        }    }  
try {        
os.close();    
} catch (IOException e) {      
e.printStackTrace();    
}}


isRecording = false; //关闭数据流

if (null != audioRecord) { //停止录制
　　audioRecord.stop();
  audioRecord.release();
　　audioRecord = null;
  recordingThread = null;
}
```

