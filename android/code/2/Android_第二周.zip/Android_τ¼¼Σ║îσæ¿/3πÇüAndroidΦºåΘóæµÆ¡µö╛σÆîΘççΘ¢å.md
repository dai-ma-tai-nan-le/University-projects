## 3、Android视频播放和采集

**@author：于洪伟**



### 3.1、Android中播放视频

在Android中，我们有三种方式来实现视频的播放：

1、使用其自带的播放器。指定Action为ACTION_VIEW,Data为Uri，Type为其MIME类型。

2、使用VideoView来播放。在布局文件中使用VideoView结合MediaController来实现对其控制。

3、使用MediaPlayer类和SurfaceView来实现，这种方式很灵活。

下面逐一进行介绍：

#### 3.1.1、自带播放器

代码如下所示：

```java
Uri uri=Uri.parse(Environment.getExternalStorageDirectory().getPath()+"/Test_Movie.m4v");   
//调用系统自带的播放器  
Intent intent = new Intent(Intent.ACTION_VIEW);  
Log.v("URI:", uri.toString());  
intent.setDataAndType(uri, "video/mp4");  
startActivity(intent);  
```



#### 3.1.2、使用VideoView

使用VideoView控件，实现视频的播放。具体的代码如下所示：

```java
Uri uri =Uri.parse(Environment.getExternalStorageDirectory().getPath()+"/Test_Movie.m4v");  
VideoView videoView = (VideoView)this.findViewById(R.id.video_view);  
videoView.setMediaController(new MediaController(this));  
videoView.setVideoURI(uri);  
videoView.start();  
videoView.requestFocus();  
```



#### 3.1.3、MediaPlayer+SurfaceView

* SurfaceView是视图(View)的继承类，这个视图里内嵌了一个专门用于绘制的Surface。

* 程序开发者可以控制这个Surface的格式和尺寸。Surfaceview控制这个Surface的绘制位置。surface是纵深排序(Z-ordered)的，这表明它总在自己所在窗口的后面。surface的排版显示受到视图层级关系的影响， surface的内容会被它的兄弟视图遮挡，这一特性可以用来放置遮盖物(overlays)(例如，文本和按钮等控件)。可以在主线程之外的线程中向屏幕绘图。这样可以避免画图任务繁重的时候造成主线程阻塞，从而提高了程序的反应速度。在游戏开发中多用到SurfaceView，游戏中的背景、人物、动画等等尽量在画布canvas中画出。

* 可以通过SurfaceHolder接口访问surface，getHolder()方法可以得到这个接口。 surfaceview变得可见时，surface被创建；surfaceview隐藏前，surface被销毁。这样能节省资源。如果你要查看 surface被创建和销毁的时机，可以重载surfaceCreated(SurfaceHolder)和 surfaceDestroyed(SurfaceHolder)。
* surfaceview的核心在于提供了两个线程：
  * UI线程
  * 渲染线程

* 注意事项：

  * 所有SurfaceView和SurfaceHolder.Callback的方法都应该在UI线程里调用，一般来说就是应用程序主线程。渲染线程所要访问的各种变量应该作同步处理。
  * 由于surface可能被销毁，它只在SurfaceHolder.Callback.surfaceCreated()和 SurfaceHolder.Callback.surfaceDestroyed()之间有效，所以要确保渲染线程访问的是合法有效的surface。

* 继承SurfaceView并实现SurfaceHolder.Callback接口,需要重写以下方法：

  * surfaceChanged：在surface的大小发生改变时激发
  * surfaceCreated：在创建时激发，一般在这里调用画图的线程。
  * surfaceDestroyed：销毁时激发，一般在这里将画图的线程停止、释放。

* 示例代码如下所示：

  ```java
  urfaceView = (SurfaceView) findViewById(R.id.surfaceview);
  surfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
    private void drawCanvas(Bitmap bitmap) {
      Canvas canvas = surfaceView.getHolder().lockCanvas();
      if (canvas != null) {
        canvas.drawBitmap(bitmap, 0, 0, null);
        surfaceView.getHolder().unlockCanvasAndPost(canvas);
      }
    }
  
    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
      if (mediaPlayer!=null){
        if (mediaPlayer.isPlaying()) {
          mediaPlayer.stop();
        }
        mediaPlayer.release();
        mediaPlayer = null;
      }
    }
  
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
      try {
        if (mediaPlayer == null) {
          mediaPlayer = new MediaPlayer();
          mediaPlayer.setDataSource(SplashActivity.this, Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.welcome));
          mediaPlayer.setLooping(true);
          mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
              mediaPlayer.start();
            }
          });
          mediaPlayer.setDisplay(surfaceView.getHolder());
          mediaPlayer.prepareAsync();
        }
      } catch (IOException e) {
        ToastUtils.ToastShortCenter(SplashActivity.this, e.getMessage());
      }
    }
  
    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) 	{}
  });
  ```



### 3.2、视频的采集

#### 3.2.1、视频相关概念

* 分辨率：用以`横向`和`纵向`的像素点个数来衡量一副图像的大小，比如`1080*960`，其中`1080`表示`横向`的像素点个数为`1080`个，`960`表示`纵向`的像素点个数为`960`个。
* 帧率：`1s`内有多少个副图像，比如`30fps`，表示`1s`内有`30`副图像，即`30`帧，而`60fps`，表示`1s`内有`60`帧，更高的还有`90fps`、`120fps`，帧率越高，相对来说，画面就会更流畅。根据人眼的视觉暂留特性，`24fps`时，人眼就会认为是`流畅`的，而更高的帧率，会给人一种身临其境的感觉。
* 码率/比特率：码率，也即比特率，单位是`bps`，表示视频的比特数，计算公式是：码率=文件大小（kb)/时长(s)

#### 3.2.2、视频采集

采集视频，在手机中可以通过摄像头进行采集，那么，在`Android`也提供了很多对摄像头进行操作的类。

* Camera：该类操作相对简单，提供对摄像头的很多的操作方法，比如打开、关闭摄像头、变焦、拍照等，不过谷歌已经不建议使用，而是建议使用`CameraX`，或者是`Camera2`。
* Camera2：`Camera2`相对于`Camera`增加了很多特性，比如对`Api`的架构进行了很大的优化，比`Camera`更先进，还可以获取每帧的信息，等等，还有很多特性。当然，`Camera2`相对于`Camera`，使用上也更加复杂。
* CameraX：JetPack`家族的一员，`CameraX`是在`Camea2`之后新出的一个相机框架，可能是谷歌觉得虽然`Camera2`功能强大，但是使用起来确实麻烦了很多，所有为了在保证功能的前提的下，操作变得更简洁，所有推出了`CameraX。

##### 3.2.2.1、Camera

关于相机的使用，可以放入子线程去使用。

* **打开相机**

  ```java
  camera = Camera.open(id);
  ```

  打开相机，使用的是`Camera`类的静态方法`open()`，该方法需要传入一个`int`类型的`id`，有两个值可选：

  * Camera.CameraInfo.CAMERA_FACING_BACK：后置摄像头
  * Camera.CameraInfo.CAMERA_FACING_FRONT：前置摄像头

  注意：在获取`camera`实例后，此时摄像头并没有正在的打开

* **获取相机参数**

  ```java
  Camera.Parameters parameters = camera.getParameters();
  ```

  对`camera`进行参数设置，先得调用该方法，然后下面就会对`parameters`进行一些参数设置。

* **获取全部预览尺寸**

  ```java
  List<Camera.Size> previewSizeList = parameters.getSupportedPreviewSizes();
  ```

  通过调用`parameters.getSupportedPreviewSizes()`获取当前相机所支持的预览尺寸，因为我们传入相机的预览尺寸必须得是相机所支持的

  一般来说，我们通常希望相机的尺寸能够和屏幕一样大，或者是和屏幕同等比例，这样，显示出来的效果也就比较好，所有下面通过一个算法，找到最佳的尺寸：

  ```java
  /**
   * 寻找最合适的尺寸
   */
  public static Camera.Size findTheBestSize(List<Camera.Size> sizeList, int screenW, int screenH) {
      if (sizeList == null || sizeList.isEmpty()) {
          throw new IllegalArgumentException();
      }
      Camera.Size bestSize = sizeList.get(0);
      for (Camera.Size size : sizeList) {
          int width = size.height;
          int height = size.width;
          float ratioW = (float) width / screenW;
          float ratioH = (float) height / screenH;
          if (ratioW == ratioH) {
              bestSize = size;
              break;
          }
      }
      return bestSize;
  }
  ```

  一个参数，直接传入相机所支持的预览尺寸，后面两个参数是屏幕的尺寸

  该算法的目的就是遍历每一个预览尺寸，但预览尺寸的比例和屏幕的尺寸比例一致时，就可以返回，而如果当遍历完，还是没找到合适的尺寸，就返回第一个相机所支持的尺寸。通过此方法，就获取到了一个最佳的尺寸。

* **设置预览尺寸**

  ```java
  parameters.setPreviewSize(width, height);
  ```

* **设置预览格式**

  ```java
  parameters.setPreviewFormat(ImageFormat.NV21);
  ```

* 为相机设置参数

  ```java
  camera.setParameters(parameters);
  ```

* 设置数据缓存和回调

  `camera`提供了`addCallbackBuffer`和`setPreviewCallbackWithBuffer`的方法，用于接收预览数据和设置回调，它能够减少对象的创建：

  ```java
  camera.addCallbackBuffer(nv21Data);
  camera.setPreviewCallbackWithBuffer(this);
  ```

  设置回调后，需要重写`onPreviewFrame`方法：

  ```java
  @Override
  public void onPreviewFrame(byte[] data, Camera camera) {
      Log.d(TAG, "onPreviewFrame: " + nv21Data.length);
      camera.addCallbackBuffer(nv21Data);
      if (fos == null) {
          return;
      }
      try {
          fos.write(nv21Data);
      } catch (IOException e) {
          e.printStackTrace();
      }
  }
  ```

  在该方法中，每次回调预览数据，都会先调用`addCallbackBuffer`方法，该方法会复用对应的对象。接着后面将数据写入到文件中。

* **设置SurfaceTexture，开启预览**

​		以上只是一些列的设置，还没结束，还需要设置`SurfaceTexture`才能正常开启预览，也就才能正常获取预览回调数据，如下所示：

```java
try {
    camera.setPreviewTexture(new SurfaceTexture(0));
} catch (IOException e) {
    e.printStackTrace();
}
camera.startPreview();
```

这里设置的是一个`new`出来的`surfaceTexture`，产生的效果是无预览采样视频

你也可以使用`SurfaceView`或者`TextureView`显示预览画面。

* **停止预览，释放资源**

  当我们停止录制时，需要停止预览并释放资源：

  ```java
  private void release() {
      if (camera != null) {
          camera.stopPreview();
          camera.release();
          camera = null;
      }
      if (fos != null) {
          try {
              fos.close();
              fos = null;
          } catch (IOException e) {
              e.printStackTrace();
          }
      }
  }
  ```



##### 3.2.2.2 Camera2

Camera2是在API level 21后面取代Camera的一个API，我们以后开发的应用中实际和这个API打交到会比较多，毕竟现在很多Android几乎都API21以上了。Camera2的使用我们也和上面说的Camera一样的功能来实现一遍，了解其中的一些细节。 

首先总体了解一些Camera2用来拍照流程和相关的类。

* CameraManager：它是Android设备用来管理所有的相机设备类。例如检测打开摄像头，查看下面的相机特征。
* CameraCharacteristics：每一个相机设备拥有一些列属性和设置用来描述它。它可以通过CameraManager来获取。
* CameraCaptureSession：当我们使用Camera2从相机设备来拍照或者预览图像，应用程序必须先创建CameraCaptureSession。
* SurfaceTexture：相机预览要一个View来显示预览的数据，在使用Camera的时候我们使用的是SurfaceView这个类。使用Camera2来操作相机也要一个Surface来显示View，Surface这个对象可以通过很多类来实例话，包括SurfaceView，SurfaceTexture，MediaCodec，MediaRecorder，Allocation，和ImageReader。我们demo使用的TextureView，它内部使用的是SurfaceTexture类。
* CaptureRequest：相机应用程序要构建一个CaptureRequest用来拍照，它定义了相机设备拍照的需要的一些参数。
* CaptureRequest：一旦CaptureRequest请求被设置好，他就可以被发送到CaptureSession用来拍照或者连续重复使用。



<img src="./img/WX20220310-235221@2x.png" style="zoom:30%;" />



接下来我们的创建一个简单的预览的相机应用：

- 声明Camera权限和Camera2使用全部特征

```
<uses-permission android:name="android.permission.CAMERA" />
<uses-feature android:name="android.hardware.camera2.full"/>
```

- 创建一个View继承TextureView
  这个TextureVie用来显示相机传输过来的预览数据。
  并且在设置监听Surface可用的时候执行下面的步骤打开相机。
- 请求打开相机

```java
private void openCamera() {
        //获取CameraManager对象
        CameraManager manager = (CameraManager)
        mContext.getSystemService(Context.CAMERA_SERVICE);
        Log.e(TAG, "is camera open");
        try {
            //检测摄像头设备ID，有几个摄像头
            cameraId = manager.getCameraIdList()[0];
            //获取相机特征对象
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
            //获取相机输出流配置Map
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            assert map != null;
            //获取预览输出尺寸
            imageDimension = map.getOutputSizes(SurfaceTexture.class)[0];
            // Add permission for camera and let user grant the permission
            if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            //调用CameraManger对象打开相机函数
            manager.openCamera(cameraId, stateCallback, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
        Log.e(TAG, "openCamera X");
    }
```

这个方法现在很精简，用来打开相机设备，最后执行openCamera的时候设置了一个stateCallback，这个用来接受相机已经打开的回掉。如果相机可以使用了，那么就执行接下来的步骤把相机底层的数据显示到TextureView上面去。

- 使用TextureView来显示预览数据

```
protected void createCameraPreview() {
        try {
            Log.e(TAG, "createCameraPreview: ");
            //获取当前TextureVie的SurfaceTexture
            SurfaceTexture texture = getSurfaceTexture();
            assert texture != null;
            //设置SurfaceTexture默认的缓冲区大小，为上面得到的预览的size大小
            texture.setDefaultBufferSize(imageDimension.getWidth(), imageDimension.getHeight());
            Surface surface = new Surface(texture);
            //创建CaptureRequest对象，并且声明类型为TEMPLATE_PREVIEW，可以看出是一个预览类型
            captureRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            //设置请求的结果返回到到Surface上
            captureRequestBuilder.addTarget(surface);
            //创建CaptureSession对象
            cameraDevice.createCaptureSession(Arrays.asList(surface), new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
                    //The camera is already closed
                    if (null == cameraDevice) {
                        return;
                    }
                    Log.e(TAG, "onConfigured: ");
                    // When the session is ready, we start displaying the preview.
                    cameraCaptureSessions = cameraCaptureSession;
                    //更新预览
                    updatePreview();
                }

                @Override
                public void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {
                    Toast.makeText(mContext, "Configuration change", Toast.LENGTH_SHORT).show();
                }
            }, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }
```

上面大致就是创建一个CaptureRequest，把这个请求发送到CaptureSession会话中去。最后在回话配置成功的回掉里面更新预览的视图

- 更新预览视图

```
protected void updatePreview() {
        if (null == cameraDevice) {
            Log.e(TAG, "updatePreview error, return");
        }
        Log.e(TAG, "updatePreview: ");
        //设置相机的控制模式为自动，方法具体含义点进去（auto-exposure, auto-white-balance, auto-focus）
        captureRequestBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
        try {
            //设置重复捕获图片信息
            cameraCaptureSessions.setRepeatingRequest(captureRequestBuilder.build(), null, mBackgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }
```

OK，上面的步骤完成了一个相机的预览的功能。



再来看看一些其他的问题：

##### 切换摄像头

切换摄像头的实现和Camera API的步骤一摸一样。只是换了一个API而已。Camera是通过Camera.CameraInfo去获取相机，Camera2通过CameraManger去获取设备相机。关键代码如下：

```java
private void getDefaultCameraId() {
        mCameraManager = (CameraManager) mContext.getSystemService(Context.CAMERA_SERVICE);
        try {
            String[] cameraList = mCameraManager.getCameraIdList();
            for (int i = 0; i < cameraList.length; i++) {
                String cameraId = cameraList[i];
                if (TextUtils.equals(cameraId, CAMERA_FONT)) {
                    mCameraId = cameraId;
                    break;
                } else if (TextUtils.equals(cameraId, CAMERA_BACK)) {
                    mCameraId = cameraId;
                    break;
                }
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }
    /**
     * 切换摄像头
     */
    public void switchCamera() {
        if (TextUtils.equals(mCameraId, CAMERA_FONT)) {
            mCameraId = CAMERA_BACK;
        } else {
            mCameraId = CAMERA_FONT;
        }
        closeCamera();
        openCamera(getWidth(), getHeight());
    }
```

##### 拍照

使用Camera2API来进行拍照要使用ImageRender来实现。具体步骤如下：

* 设置ImageReader，回掉可用保存图片

  ```java
  private void setupImageReader() {
          //2代表ImageReader中最多可以获取两帧图像流
          mImageReader = ImageReader.newInstance(mPreviewSize.getWidth(), mPreviewSize.getHeight(),
                  ImageFormat.JPEG, 2);
          mImageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
              @Override
              public void onImageAvailable(ImageReader reader) {
                  mBackgroundHandler.post(new ImageSaver(reader.acquireNextImage()));
              }
          }, mBackgroundHandler);
      }
  
      private static File mImageFile;
      private ImageReader mImageReader;
  
      private static class ImageSaver implements Runnable {
          private Image mImage;
  
          private ImageSaver(Image image) {
              mImage = image;
          }
  
          @Override
          public void run() {
              ByteBuffer byteBuffer = mImage.getPlanes()[0].getBuffer();
              byte[] bytes = new byte[byteBuffer.remaining()];
              byteBuffer.get(bytes);
              FileOutputStream fileOutputStream = null;
              try {
                  fileOutputStream = new FileOutputStream(mImageFile);
                  fileOutputStream.write(bytes);
              } catch (IOException e) {
                  e.printStackTrace();
              } finally {
                  mImage.close();
                  if (fileOutputStream != null) {
                      try {
                          fileOutputStream.close();
                      } catch (IOException e) {
                          e.printStackTrace();
                      }
                  }
              }
          }
      }
  ```

* 在预览创建CameraCaptureSession的时候除了预览的TextureView，把ImageReader的Surface设置进行配置

  ```java
  //创建CaptureSession对象
              mCameraDevice.createCaptureSession(Arrays.asList(surface, mImageReader.getSurface()), new CameraCaptureSession.StateCallback() {
                  @Override
                  public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
                      //The camera is already closed
                      if (null == mCameraDevice) {
                          return;
                      }
                      Log.e(TAG, "onConfigured: ");
                      // When the session is ready, we start displaying the preview.
                      mCameraCaptureSessions = cameraCaptureSession;
                      //更新预览
                      updatePreview();
                  }
  
                  @Override
                  public void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {
                      Toast.makeText(mContext, "Configuration change", Toast.LENGTH_SHORT).show();
                  }
              }, null);
  ```

* 锁定焦点

  ```java
  private void lockFocus() {
    try {
      mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START);
      mCameraCaptureSessions.capture(mPreviewRequestBuilder.build(), mCaptureCallback, mBackgroundHandler);
    } catch (CameraAccessException e) {
      e.printStackTrace();
    }
  }
  ```

* 拍照

  ```java
  private void capture() {
          try {
              final CaptureRequest.Builder mCaptureBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
              int rotation = ((Activity) mContext).getWindowManager().getDefaultDisplay().getRotation();
              mCaptureBuilder.addTarget(mImageReader.getSurface());
              mCaptureBuilder.set(CaptureRequest.JPEG_ORIENTATION, ORIENTATIONS.get(rotation));
              CameraCaptureSession.CaptureCallback CaptureCallback = new CameraCaptureSession.CaptureCallback() {
                  @Override
                  public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, TotalCaptureResult result) {
                      Toast.makeText(mContext, "Image Saved!", Toast.LENGTH_SHORT).show();
                      unLockFocus();
                      updatePreview();
                  }
              };
              mCameraCaptureSessions.stopRepeating();
              mCameraCaptureSessions.capture(mCaptureBuilder.build(), CaptureCallback, null);
          } catch (CameraAccessException e) {
              e.printStackTrace();
          }
      }
  ```

* 解锁焦点

  ```java
  private void unLockFocus() {
    try {
      mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL);
      //mCameraCaptureSession.capture(mCaptureRequestBuilder.build(), null, mCameraHandler);
      mCameraCaptureSessions.setRepeatingRequest(mPreviewRequestBuilder.build(), null, mBackgroundHandler);
    } catch (CameraAccessException e) {
      e.printStackTrace();
    }
  }
  ```

  

