
import java.io.File;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class jishu {
    public static String regex_xuehao=".*(198\\d{5}|188\\d{5})";//学号的模糊匹配规则
    public static void main(String[] args) {
        try {
            String pathname = "F:\\大三下\\小学期\\ceshi.txt"; // 绝对路径或相对路径都可以
            File filename = new File(pathname);
            InputStreamReader reader = new InputStreamReader(new FileInputStream(filename));
            BufferedReader br = new BufferedReader(reader);
            File writename = new File("F:\\大三下\\小学期\\output.txt"); // 绝对路径，如果没有则要建立一个新的output.txt文件
            BufferedWriter out = new BufferedWriter(new FileWriter(writename));
            writename.createNewFile();
            Pattern pattern = Pattern.compile(regex_xuehao);//编译正则表达式
            List<xuehaojihe> xuehaojiheList=new ArrayList<xuehaojihe>();//学号集合
            String line = "";
            line = br.readLine();
            while (line != null) {
                if(line.matches(regex_xuehao)){
                    Matcher matcher = pattern.matcher(line);
                    matcher.find();
                    int xuehao=Integer.parseInt(matcher.group(1));
                    int index=ChaXun(xuehaojiheList,xuehao);
                    if (index==-1){
                        xuehaojihe xuehaojihe=new xuehaojihe();
                        xuehaojihe.xuehao=xuehao;
                        xuehaojihe.cishu++;
                        xuehaojiheList.add(xuehaojihe);
//                        System.out.println(matcher.group(1));
                    }
                    else {
                        xuehaojiheList.get(index).cishu++;
                    }
                }
                line = br.readLine();
            }
            for (int i=0;i<xuehaojiheList.size();i++){
                String output=xuehaojiheList.get(i).xuehao+" 次数："+xuehaojiheList.get(i).cishu+"\n";
                out.write(output);
            }
            out.flush();
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//遍历学号集合，如果有则返回集合索引，否则返回-1
    public static int ChaXun(List<xuehaojihe> xuehaojiheList, int xuehao){
        int index=-1;
        for (int i=0;i<xuehaojiheList.size();i++){
            if(xuehaojiheList.get(i).xuehao==xuehao){
                index=i;
            }
        }
        return index;
    }
//学号集合类，包括学号和出现的次数，次数初始为0
    static class xuehaojihe{
        public int xuehao;//学号
        public int cishu;//次数

        public xuehaojihe(){
            cishu=0;
        }

        public int getXuehao() {
            return xuehao;
        }

        public void setXuehao(int xuehao) {
            this.xuehao = xuehao;
        }

        public int getCishu() {
            return cishu;
        }

        public void setCishu(int cishu) {
            this.cishu = cishu;
        }

    }
}
