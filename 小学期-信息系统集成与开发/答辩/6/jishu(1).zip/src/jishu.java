
import java.io.File;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class jishu {
    public static String regex_xuehao=".*(198\\d{5}|188\\d{5})";//学号的模糊匹配规则
    public static String regex_laoshi="^王志海$";
    public static String regex_wenhao="^\\？+$";
    public static void main(String[] args) {
        try {
            // 输入的文本文件：绝对路径或相对路径都可以
            String pathname = "F:\\大三下\\小学期\\ceshi78.txt";
            File filename = new File(pathname);
            InputStreamReader reader = new InputStreamReader(new FileInputStream(filename),"gbk");
            BufferedReader br = new BufferedReader(reader);
            // 输出的文本文件：绝对路径或相对路径都可以
            File writename = new File("F:\\大三下\\小学期\\output.txt");
            BufferedWriter out = new BufferedWriter(new FileWriter(writename));
            writename.createNewFile();
            Pattern pattern = Pattern.compile(regex_xuehao);//编译正则表达式
            List<xuehaojihe> xuehaojiheList=new ArrayList<xuehaojihe>();//学号集合
            String line = "";
            line = br.readLine();
            boolean flag=false;//老师判断标记
            boolean youxiao=false;//有效“？”判断标记
            int j=0;//次数<5
            while (line != null) {
//                System.out.println(line);
                if (flag){
                    if (line.matches(regex_wenhao)){
                        youxiao=true;
                    }else {
                        flag=false;
                    }
                }

                if (line.matches(regex_laoshi)){
                    if (youxiao){
                        youxiao=false;
                    }else {
                        flag=true;
                    }
                }

                if(line.matches(regex_xuehao)){
                    Matcher matcher = pattern.matcher(line);
                    matcher.find();
                    int xuehao=Integer.parseInt(matcher.group(1));
                    int index=ChaXun(xuehaojiheList,xuehao);
                    if (index==-1){
                        xuehaojihe xuehaojihe=new xuehaojihe();
                        xuehaojihe.xuehao=xuehao;
                        xuehaojihe.cishu++;
                        if (youxiao){
                            if (j<5){
                                xuehaojihe.youxiaocishu++;
                                j++;
                            }else {
                                j=0;
                                youxiao=false;
                            }
                        }else {
                            j=0;
                            youxiao=false;
                        }
                        xuehaojiheList.add(xuehaojihe);
//                        System.out.println(matcher.group(1));
                    }
                    else {
                        xuehaojiheList.get(index).cishu++;
                        if (youxiao){
                            if (j<5){
                                xuehaojiheList.get(index).youxiaocishu++;
                                j++;
                            }else {
                                j=0;
                                youxiao=false;
                            }
                        }else {
                            j=0;
                            youxiao=false;
                        }
                    }
                }
                line = br.readLine();
            }
            for (int i=0;i<xuehaojiheList.size();i++){
                String output=xuehaojiheList.get(i).xuehao+" 次数："+xuehaojiheList.get(i).cishu+" 有效次数："+xuehaojiheList.get(i).youxiaocishu+"\n";
                out.write(output);
            }
            out.flush();
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//遍历学号集合，如果有则返回集合索引，否则返回-1
    public static int ChaXun(List<xuehaojihe> xuehaojiheList, int xuehao){
        int index=-1;
        for (int i=0;i<xuehaojiheList.size();i++){
            if(xuehaojiheList.get(i).xuehao==xuehao){
                index=i;
            }
        }
        return index;
    }
//学号集合类，包括学号和出现的次数，次数初始为0
    static class xuehaojihe{
        public int xuehao;//学号
        public int cishu;//次数
        public int youxiaocishu;//有效次数

        public xuehaojihe(){
            cishu=0;
            youxiaocishu=0;
        }


        public int getYouxiaocishu() {
            return youxiaocishu;
        }

        public void setYouxiaocishu(int youxiaocishu) {
            this.youxiaocishu = youxiaocishu;
        }

        public int getXuehao() {
            return xuehao;
        }

        public void setXuehao(int xuehao) {
            this.xuehao = xuehao;
        }

        public int getCishu() {
            return cishu;
        }

        public void setCishu(int cishu) {
            this.cishu = cishu;
        }

    }
}
