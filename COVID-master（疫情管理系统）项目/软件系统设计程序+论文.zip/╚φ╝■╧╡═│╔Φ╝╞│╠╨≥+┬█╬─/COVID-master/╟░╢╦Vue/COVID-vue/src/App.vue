<template>
  <div id="app">
  <router-view></router-view>
  </div>
  
</template>

<style>
  .el-header {
    background-color: #B3C0D1;
    color: #333;
    line-height: 60px;
  }
  
  .el-aside {
    color: #333;
  }
</style>

<script>
  export default {
   
  };
</script>
