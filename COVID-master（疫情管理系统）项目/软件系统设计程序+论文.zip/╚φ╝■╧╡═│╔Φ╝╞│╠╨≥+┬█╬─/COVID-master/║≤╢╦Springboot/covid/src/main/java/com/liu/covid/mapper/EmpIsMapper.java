package com.liu.covid.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.liu.covid.entity.EmpIs;
import org.springframework.stereotype.Repository;

@Repository
public interface EmpIsMapper extends BaseMapper<EmpIs> {
}
