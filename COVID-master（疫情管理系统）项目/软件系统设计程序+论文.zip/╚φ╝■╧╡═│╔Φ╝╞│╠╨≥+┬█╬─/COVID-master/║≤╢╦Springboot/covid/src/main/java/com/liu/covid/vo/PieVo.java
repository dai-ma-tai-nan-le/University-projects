package com.liu.covid.vo;

import lombok.Data;

@Data
public class PieVo {
    private String name;
    private Integer value;
}
