package com.liu.covid.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.liu.covid.entity.EmpIden;
import org.springframework.stereotype.Repository;

@Repository
public interface EmpIdenMapper extends BaseMapper<EmpIden> {
}
