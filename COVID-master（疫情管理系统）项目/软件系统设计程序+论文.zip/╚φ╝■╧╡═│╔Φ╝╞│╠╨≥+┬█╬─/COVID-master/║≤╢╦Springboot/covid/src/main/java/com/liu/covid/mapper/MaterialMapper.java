package com.liu.covid.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.liu.covid.entity.MaterialManage;
import org.springframework.stereotype.Repository;

@Repository
public interface MaterialMapper extends BaseMapper<MaterialManage> {
}
