package com.liu.covid.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.liu.covid.entity.Department;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartMapper extends BaseMapper<Department> {
}
