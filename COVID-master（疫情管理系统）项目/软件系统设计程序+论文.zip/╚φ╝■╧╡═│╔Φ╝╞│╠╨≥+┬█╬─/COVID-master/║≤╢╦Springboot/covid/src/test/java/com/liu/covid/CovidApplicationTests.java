package com.liu.covid;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.liu.covid.entity.User;
import com.liu.covid.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

@SpringBootTest
class CovidApplicationTests {

    @Resource
    private UserMapper userMapper;
    @Test
    void contextLoads() {
        QueryWrapper queryWrapper = new QueryWrapper();
        System.out.println(userMapper.selectList(queryWrapper));
    }

}
