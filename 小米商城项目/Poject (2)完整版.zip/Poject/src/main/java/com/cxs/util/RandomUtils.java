package com.cxs.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

/**
 * <p>Project:poject01 - RandomUtils
 * <p>powered by 陈栩生 On 2022-10-30 12:50:19
 *
 * @author 陈栩生
 * @version 1.0
 * @since 1.8
 */
public class RandomUtils {
    public static String createActive(){
        return getTime()+Integer.toHexString(new Random().nextInt(900)+100);
    }

    public static String getTime() {
        return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(Calendar.getInstance().getTime());
    }

    public static String createOrderId(){
        return getTime();
    }
}
