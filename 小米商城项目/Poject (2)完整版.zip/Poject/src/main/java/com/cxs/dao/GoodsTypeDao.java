package com.cxs.dao;

import com.cxs.entity.GoodsType;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface GoodsTypeDao {
    @Select("select * from tb_goods_type where level=#{level}")
    List<GoodsType> selectByLevel(int level);

    @Select("select * from tb_goods_type where id=#{id}")
    List<GoodsType> selectById(int id);
}
