package com.cxs.filter;

import com.cxs.entity.User;
import com.cxs.service.UserService;
import com.cxs.service.ipml.UserServiceIpml;
import com.cxs.util.Base64Utils;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter(filterName = "AutoLoginFilter",urlPatterns = "/index.jsp")
public class AutoLoginFilter implements Filter {
    public void init(FilterConfig config) throws ServletException {
    }

    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        //(1)判断是否是登录状态
        HttpServletRequest request= (HttpServletRequest) req;
        HttpServletResponse response= (HttpServletResponse) resp;
        User user = (User) request.getSession().getAttribute("user");
        if(user!=null){
            chain.doFilter(req, resp);
            return;
        }
        //(2)获取cookie实现自动登录
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if(cookie.getName().equals("userinfo")){
                    try {
                        String userinfo = cookie.getValue();
                        userinfo= Base64Utils.decode(userinfo);
                        System.out.println(userinfo);
                        String[] arr = userinfo.split("#");
                        UserService userService=new UserServiceIpml();
                        User u=userService.login(arr[0],arr[1]);
                        request.getSession().setAttribute("user", u);
                    } catch (Exception e) {
                        e.printStackTrace();
                        cookie.setMaxAge(0);
                        response.addCookie(cookie);
                    }
                }
            }
        }
        chain.doFilter(request, response);
    }
}
