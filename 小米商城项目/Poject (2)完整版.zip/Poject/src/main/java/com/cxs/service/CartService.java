package com.cxs.service;

import com.cxs.entity.Cart;

import java.util.List;

public interface CartService {
    Cart findByUidAndPid(int uid, int pid);

    void add(Cart cart);

    void update(Cart cart);

    List<Cart> findByUid(int uid);

    void delete(int uid, int pid);

    void deleteByUid(int uid);
}
