package com.cxs.service;

import com.cxs.entity.Goods;
import com.cxs.entity.PageBean;
import com.github.pagehelper.PageInfo;

import java.util.Map;

public interface GoodsService {
    PageBean<Goods> findByPage(Map<String, Object> condition);

    PageInfo<Goods> findByPage2(Map<String, Object> condition);

    Goods findById(int gid);
}
