package com.cxs.service;

import com.cxs.entity.Order;
import com.cxs.entity.OrderDetail;

import java.util.List;

/**
 * <p>Project:poject01 - OrderService
 * <p>powered by 陈栩生 On 2022-10-30 13:03:26
 *
 * @author 陈栩生
 * @version 1.0
 * @since 1.8
 */
public interface OrderService {
    void saveOrder(Order order, List<OrderDetail> orderDetails);

    void updateStatus(String oid, String status);
}
