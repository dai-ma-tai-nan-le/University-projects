package com.cxs.dao;

import com.cxs.entity.Cart;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface CartDao {
    @Select("select * from tb_cart where id=#{uid} and pid=#{pid}")
    Cart selectByUidAndPid(@Param("uid") int uid,@Param("pid") int pid);

    @Insert("insert into tb_cart values(#{id},#{pid},#{num},#{money})")
    void insertCart(Cart cart);

    @Update("update tb_cart set num=#{num},money=#{money} where id=#{id} and pid=#{pid}")
    void update(Cart cart);

    @Select("select c.*,g.name,g.pubdate,g.picture,g.price,g.star,g.intro,g.typeid " +
            "from tb_cart as c inner join tb_goods as g on c.pid=g.id where c.id=#{uid}")
    @Results({
            @Result(property = "id",column = "id",id = true),
            @Result(property = "pid",column = "pid"),
            @Result(property = "num",column = "num"),
            @Result(property = "money",column = "money"),
            @Result(property = "goods.name",column = "name"),
            @Result(property = "goods.id",column = "pid"),
            @Result(property = "goods.pubdate",column = "pubdate"),
            @Result(property = "goods.picture",column = "picture"),
            @Result(property = "goods.price",column = "price"),
            @Result(property = "goods.star",column = "star"),
            @Result(property = "goods.intro",column = "intro"),
            @Result(property = "goods.typeid",column = "typeid")
    })
    List<Cart> selectByUid(int uid);

    @Delete("delete from tb_cart where id=#{uid} and pid=#{pid}")
    void delete(@Param("uid") int uid, @Param("pid") int pid);

    @Delete("delete from tb_cart where id=#{uid}")
    void deleteByUid(int uid);
}
