package com.cxs.dao;

import com.cxs.entity.Order;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

/**
 * <p>Project:poject01 - OrderDao
 * <p>powered by 陈栩生 On 2022-10-30 13:09:33
 *
 * @author 陈栩生
 * @version 1.0
 * @since 1.8
 */
public interface OrderDao {
    @Insert("insert into tb_order values(#{id},#{uid},#{money},#{status},#{time},#{aid})")
    void add(Order order);

    @Update("update tb_order set status=#{status} where id=#{oid}")
    void updateStatus(@Param("oid") String oid, @Param("status") String status);
}
