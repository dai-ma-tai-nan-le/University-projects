package com.cxs.service;

import com.cxs.entity.GoodsType;

import java.util.List;

public interface GoodsTypeService {
    List<GoodsType> findByLevel(int level);
}
