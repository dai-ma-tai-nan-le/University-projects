package com.cxs.service.ipml;

import com.cxs.dao.AddressDao;
import com.cxs.entity.Address;
import com.cxs.service.AddressService;
import com.cxs.util.MyBatisUtils;

import java.util.List;

/**
 * <p>Project:poject01 - AddressServiceImpl
 * <p>powered by 作者名 On 2022-10-28 11:42:03
 *
 * @author 作者名
 * @version 1.0
 * @since 1.8
 */
public class AddressServiceImpl implements AddressService {
    private AddressDao addressDao = MyBatisUtils.getMapper(AddressDao.class);

    @Override
    public List<Address> findByUid(int uid) {
        List<Address> addresses = addressDao.selectByUid(uid);
        MyBatisUtils.closeSession();
        return addresses;
    }

    @Override
    public void addAddress(Address address) {
        try {
            addressDao.insert(address);
            MyBatisUtils.commit();
        } catch (Exception e) {
            e.printStackTrace();
            MyBatisUtils.rollback();
            throw e;
        }
    }

    @Override
    public void deleteById(int aid) {
        try {
            addressDao.deleteById(aid);
            MyBatisUtils.commit();
        } catch (Exception e) {
            e.printStackTrace();
            MyBatisUtils.rollback();
            throw e;
        }
    }

    @Override
    public void update(Address address) {
        try {
            addressDao.update(address);
            MyBatisUtils.commit();
        } catch (Exception e) {
            e.printStackTrace();
            MyBatisUtils.rollback();
            throw e;
        }
    }

    @Override
    public void defaultAddress(int uid, int aid) {
        try {
            //level=0
            addressDao.updateAll(uid);
            //level=1
            addressDao.updateDefault(aid);
            MyBatisUtils.commit();
        } catch (Exception e) {
            e.printStackTrace();
            MyBatisUtils.rollback();
            throw e;
        }
    }
}
