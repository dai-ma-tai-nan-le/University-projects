package com.cxs.controller;

import com.cxs.entity.Goods;
import com.cxs.entity.PageBean;
import com.cxs.service.GoodsService;
import com.cxs.service.ipml.GoodsServiceImpl;
import com.cxs.util.StringUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@WebServlet(urlPatterns = "/goodsservlet")
public class GoodsServlet extends BaseServlet{
    //分页查询商品
    public String getGoodsListByTypeId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1接收分页参数
        String pageNum = request.getParameter("pageNum");
        String pageSize = request.getParameter("pageSize");
        //默认值
        int pn=1;
        int ps=8;
        try {
            if(!StringUtils.isEmpty(pageNum)){
                pn=Integer.parseInt(pageNum);
                if(pn<1){
                    pn=1;
                }
            }
            if(!StringUtils.isEmpty(pageSize)){
                ps=Integer.parseInt(pageSize);
                if(ps<1){
                    ps=8;
                }
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        //2创建Map集合
        Map<String,Object> condition=new HashMap<>();
        condition.put("pageNum", pn);
        condition.put("start", (pn-1)*ps);
        condition.put("pageSize", ps);
        //3获取查询条件
        //typeId=1&name=java
        String typeId = request.getParameter("typeId");
        String name = request.getParameter("name");
        condition.put("name",name);
        //空判断
        if (StringUtils.isEmpty(typeId)&&StringUtils.isEmpty(name)){
            return "redirect:/index.jsp";
        }
        try {
            condition.put("typeId", Integer.parseInt(typeId));
        } catch (NumberFormatException e) {
            //e.printStackTrace();
            typeId=null;
        }
        //4创建业务对象
        try {
            GoodsService goodsService = new GoodsServiceImpl();
            PageBean<Goods> pageBean=goodsService.findByPage(condition);
            System.out.println(pageBean.getTotalSize()+"..."+pageBean.getPageCount());
            System.out.println(pageBean.getData().toString());
            //5放入域中
            request.setAttribute("pageBean", pageBean);
            request.setAttribute("typeId",typeId);
            request.setAttribute("name",name);
            return "/goodsList.jsp";
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("msg","查询失败:"+e.getMessage() );
            return "/message.jsp";
        }
    }

    //根据商品id查询商品
    public String getGoodsById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        //获取请求参数
        String id = request.getParameter("id");
        if(StringUtils.isEmpty(id)){
            request.setAttribute("msg","未查询的此商品");
            return "/message";
        }
        //创建业务对象
        GoodsService goodsService=new GoodsServiceImpl();
        //调用方法
        try {
            Goods goods = goodsService.findById(Integer.parseInt(id));
            System.out.println(goods.toString());
            request.setAttribute("goods",goods);
            return "/goodsDetail.jsp";
        } catch (NumberFormatException e) {
            e.printStackTrace();
            request.setAttribute("msg","查询失败"+e.getMessage());
            return "/message.jsp";
        }
    }
}
