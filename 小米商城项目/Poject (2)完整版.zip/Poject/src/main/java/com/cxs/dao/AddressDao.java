package com.cxs.dao;

import com.cxs.entity.Address;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p>Project:poject01 - AddressDao
 * <p>powered by 陈栩生 On 2022-10-28 12:41:07
 *
 * @author 陈栩生
 * @version 1.0
 * @since 1.8
 */
public interface AddressDao {
    @Select("select * from tb_address where uid=#{uid}")
    List<Address> selectByUid(int uid);

    @Insert("insert into tb_address values(null,#{detail},#{name},#{phone},#{uid},#{level})")
    void insert(Address address);

    @Delete("delete from tb_address where id=#{aid}")
    void deleteById(int aid);

    @Update("update tb_address set name=#{name},phone=#{phone},detail=#{detail} where id=#{id}")
    void update(Address address);

    @Update("update tb_address set level=0 where uid=#{uid}")
    void updateAll(int uid);

    @Update("update tb_address set level=1 where id=#{aid}")
    void updateDefault(int aid);
}
