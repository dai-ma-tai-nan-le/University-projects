package com.cxs.dao;

import com.cxs.entity.Goods;
import com.cxs.entity.GoodsType;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;
import java.util.Map;

public interface GoodsDao {
    @Select("<script>" +
            "select count(*) from tb_goods " +
            "<where>" +
            "<if test='typeId!=null'>" +
            " and typeId=#{typeId}"+
            "</if>" +
            "<if test='name!=null'>" +
            " and name like '%' #{name} '%'"+
            "</if>" +
            "</where>" +
            "</script>")
    long getCount(Map<String, Object> condition);

    @Select("<script>" +
            "select * from tb_goods " +
            "<where>" +
            "<if test='typeId!=null'>" +
            " and typeId=#{typeId}"+
            "</if>" +
            "<if test='name!=null'>" +
            " and name like '%' #{name} '%'"+
            "</if>" +
            "</where>" +
            " limit #{start},#{pageSize} "+
            "</script>")
    List<Goods> selectByPage(Map<String, Object> condition);

    @Select("<script>" +
            "select * from tb_goods " +
            "<where>" +
            "<if test='typeId!=null'>" +
            " and typeId=#{typeId}"+
            "</if>" +
            "<if test='name!=null'>" +
            " and name like '%' #{name} '%'"+
            "</if>" +
            "</where>"+
            "</script>")
    List<Goods> select(Map<String, Object> condition);

//    @Results(
//            {
//                    @Result(property = "goodsType.id",column = "typeid"),
//                    @Result(property = "goodsType.name",column = "tname")
//            }
//    )
//    @Select("select g.*,t.name as tname from tb_goods as g inner join tb_goods_type as t on g.typeid=t.id where g.id=#{gid}")
    @Results(
            {
                    @Result(property = "goodsType",column = "typeId",
                            one = @One(select="com.cxs.dao.GoodsTypeDao.selectById",fetchType = FetchType.LAZY),
                            javaType = GoodsType.class)
            }
    )
    @Select("select * from tb_goods where id=#{gid}")
    Goods selectById(int gid);
}
