package com.cxs.service.ipml;

import com.cxs.dao.CartDao;
import com.cxs.entity.Cart;
import com.cxs.entity.Goods;
import com.cxs.service.CartService;
import com.cxs.service.GoodsService;
import com.cxs.util.MyBatisUtils;

import java.util.List;

public class CartServiceImpl implements CartService {
    private CartDao cartDao= MyBatisUtils.getMapper(CartDao.class);
    @Override
    public Cart findByUidAndPid(int uid, int pid) {
        Cart cart;
        try {
            cart = cartDao.selectByUidAndPid(uid,pid);
            MyBatisUtils.clearCache();
        } finally {
            MyBatisUtils.closeSession();
        }

        return cart;
    }

    @Override
    public void add(Cart cart) {
        try {
//            GoodsService goodsService = new GoodsServiceImpl();
//            Goods goods = goodsService.findById(cart.getId());//sqlSession已经关闭
//            if (goods==null){
//                throw new RuntimeException("商品不存在...");
//            }
            cartDao.insertCart(cart);
            MyBatisUtils.commit();
        } catch (Exception e) {
            e.printStackTrace();
            MyBatisUtils.rollback();
            throw e;
        }
    }

    @Override
    public void update(Cart cart) {
        try {
            cartDao.update(cart);
            MyBatisUtils.commit();
        } catch (Exception e) {
            e.printStackTrace();
            MyBatisUtils.rollback();
            throw e;
        }
    }

    @Override
    public List<Cart> findByUid(int uid) {
        List<Cart> cartList;
        try {
            cartList = cartDao.selectByUid(uid);
            return cartList;
        } finally {
            MyBatisUtils.closeSession();
        }
    }

    @Override
    public void delete(int uid, int pid) {
        try {
            cartDao.delete(uid,pid);
            MyBatisUtils.commit();
        } catch (Exception e){
            MyBatisUtils.rollback();
            throw e;
        }
    }

    @Override
    public void deleteByUid(int uid) {
        try {
            cartDao.deleteByUid(uid);
            MyBatisUtils.commit();
        } catch (Exception e){
            MyBatisUtils.rollback();
            throw e;
        }
    }
}
