package com.cxs.service.ipml;

import com.cxs.dao.GoodsTypeDao;
import com.cxs.entity.GoodsType;
import com.cxs.service.GoodsTypeService;
import com.cxs.util.MyBatisUtils;

import java.util.List;

public class GoodsTypeServiceImpl implements GoodsTypeService {
    private GoodsTypeDao goodsTypeDao= MyBatisUtils.getMapper(GoodsTypeDao.class);
    @Override
    public List<GoodsType> findByLevel(int level) {
        List<GoodsType> goodsTypes = goodsTypeDao.selectByLevel(level);
        MyBatisUtils.closeSession();
        return goodsTypes;
    }
}
