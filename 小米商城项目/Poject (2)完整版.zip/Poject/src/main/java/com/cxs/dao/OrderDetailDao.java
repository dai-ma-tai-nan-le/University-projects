package com.cxs.dao;

import com.cxs.entity.OrderDetail;
import org.apache.ibatis.annotations.Insert;

/**
 * <p>Project:poject01 - OrderDetailDao
 * <p>powered by 陈栩生 On 2022-10-30 13:16:10
 *
 * @author 陈栩生
 * @version 1.0
 * @since 1.8
 */
public interface OrderDetailDao {
    @Insert("insert into tb_orderdetail values(null,#{oid},#{pid},#{num},#{money})")
    void add(OrderDetail od);
}
