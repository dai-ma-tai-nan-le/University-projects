package com.cxs.controller;

import com.cxs.entity.*;
import com.cxs.service.AddressService;
import com.cxs.service.CartService;
import com.cxs.service.OrderService;
import com.cxs.service.ipml.AddressServiceImpl;
import com.cxs.service.ipml.CartServiceImpl;
import com.cxs.service.ipml.OrderServiceImpl;
import com.cxs.util.RandomUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet(name = "OrderServlet",urlPatterns = "/orderservlet")
public class OrderServlet extends BaseServlet{
    //订单预览
    public String getOrderView(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        if(user==null){
            return "redirect:/login.jsp";
        }
        //获取购物车信息
        CartService cartService=new CartServiceImpl();
        List<Cart> cartList = cartService.findByUid(user.getId());
        if(cartList==null||cartList.size()==0){
            request.setAttribute("msg","购物车为空");
            return "/message.jsp";
        }
        //获取收货地址
        AddressService addressServicr = new AddressServiceImpl();
        List<Address> addresses = addressServicr.findByUid(user.getId());

        //放入域中
        request.setAttribute("cartList",cartList);
        request.setAttribute("addList",addresses);

        return "/order.jsp";
    }

    //提交订单addOrder
    public String addOrder(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        if(user==null){
            return "redirect:/login.jsp";
        }
        String aid = request.getParameter("aid");
        //获取购物车的数据
        CartService cartService=new CartServiceImpl();
        List<Cart> cartList = cartService.findByUid(user.getId());
        if(cartList==null||cartList.size()==0){
            request.setAttribute("msg","购物车为空请添加商品到购物车");
            return "/message.jsp";
        }
        //创建订单号
        String oid = RandomUtils.createOrderId();
        //创建订单详情
        List<OrderDetail> orderDetails = new ArrayList<>();
        BigDecimal sum = new BigDecimal(0);
        for (Cart cart : cartList) {
            OrderDetail orderDetail = new OrderDetail(null,oid,cart.getPid(),cart.getNum(),cart.getMoney());
            orderDetails.add(orderDetail);
            sum = sum.add(cart.getMoney());
        }
        //创建订单
        Order order = new Order(oid, user.getId(), sum,"1",new Date(),Integer.parseInt(aid));
        //创建业务
        try {
            OrderService orderService = new OrderServiceImpl();
            orderService.saveOrder(order,orderDetails);
            request.setAttribute("order",order);
            return "/orderSuccess.jsp";
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("msg","订单提交失败"+e.getMessage());
            return "/message.jsp";
        }
    }

}
