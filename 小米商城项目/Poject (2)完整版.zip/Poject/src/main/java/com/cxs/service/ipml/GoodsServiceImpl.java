package com.cxs.service.ipml;

import com.cxs.dao.GoodsDao;
import com.cxs.entity.Goods;
import com.cxs.entity.PageBean;
import com.cxs.service.GoodsService;
import com.cxs.util.MyBatisUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import java.util.List;
import java.util.Map;

public class GoodsServiceImpl implements GoodsService {
    private GoodsDao goodsDao= MyBatisUtils.getMapper(GoodsDao.class);
    @Override
    public PageBean<Goods> findByPage(Map<String, Object> condition) {
        Integer pageNum = (Integer) condition.get("pageNum");
        Integer pageSize = (Integer) condition.get("pageSize");
        long totalSize=goodsDao.getCount(condition);
        List<Goods> data=goodsDao.selectByPage(condition);
        PageBean<Goods> pageBean=new PageBean<>(pageNum, pageSize, totalSize, data);
        MyBatisUtils.closeSession();
        return pageBean;
    }

    @Override
    public PageInfo<Goods> findByPage2(Map<String, Object> condition) {
        Integer pageNum = (Integer) condition.get("pageNum");
        Integer pageSize = (Integer) condition.get("pageSize");
        //拦截器，拼接分页查询语句 limit ?,?
        PageHelper.startPage(pageNum, pageSize);
        List<Goods> data=goodsDao.select(condition);
        PageInfo<Goods> pageInfo=new PageInfo<>(data);
        return pageInfo;
    }

    @Override
    public Goods findById(int gid) {
        Goods goods = goodsDao.selectById(gid);
        MyBatisUtils.clearCache();//清除缓存
        MyBatisUtils.closeSession();
        if(goods==null){
            throw new RuntimeException("商品不存在");
        }
        return goods;
    }
}
