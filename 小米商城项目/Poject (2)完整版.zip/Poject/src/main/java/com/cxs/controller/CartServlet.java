package com.cxs.controller;

import com.cxs.entity.Cart;
import com.cxs.entity.Goods;
import com.cxs.entity.User;
import com.cxs.service.CartService;
import com.cxs.service.GoodsService;
import com.cxs.service.ipml.CartServiceImpl;
import com.cxs.service.ipml.GoodsServiceImpl;
import com.cxs.util.StringUtils;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

@WebServlet(name = "CartServlet", value = "/cartservlet")
public class CartServlet extends BaseServlet {
    public String addCart(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
        //判断是否是登录状态
        User user = (User) request.getSession().getAttribute("user");
        if (user==null){
            return "redirect:/login.jsp";
        }
        //获取数据
        String goodsId = request.getParameter("goodsId");
        String number = request.getParameter("number");
        //校验数据
        if(StringUtils.isEmpty(goodsId)){
            //添加购物车失败
            return "/message.jsp";
        }
        int num=1;
        if (!StringUtils.isEmpty(number)){
            try {
                num=Integer.parseInt(number);
                if (num<1||num>5){
                    num=1;
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        //创建业务对象
        CartService cartService = new CartServiceImpl();
        Cart cart = cartService.findByUidAndPid(user.getId(),Integer.parseInt(goodsId));
        GoodsService goodsService = new GoodsServiceImpl();
        Goods goods = goodsService.findById(Integer.parseInt(goodsId));
        if(goods == null){
            request.setAttribute("msg","添加购物车失败");
            return "/message.jsp";
        }
        //重新绑定线程
        cartService = new CartServiceImpl();
        try {
            System.out.println("cart:"+cart);
            if (cart==null){
                //添加数据
                System.out.println("添加购物车。。");
                cart=new Cart(user.getId(),Integer.parseInt(goodsId),num,goods.getPrice().multiply(new BigDecimal(num)),null);
                cartService.add(cart);
            }else {
                //更新数据
                cart.setNum(cart.getNum()+num);
                cart.setMoney(goods.getPrice().multiply(new BigDecimal(cart.getNum())));
                cartService.update(cart);
            }
            return "/cartSuccess.jsp";
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("msg","添加失败:"+e.getMessage());
            return "/message.jsp";
        }
    }

    //method=getCart
    public String getCart(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
        //判断是否是登录状态
        User user = (User) request.getSession().getAttribute("user");
        if (user==null){
            return "redirect:/login.jsp";
        }
        //创建业务对象
        CartService cartService = new CartServiceImpl();
        List<Cart> cartList = cartService.findByUid(user.getId());
        if(cartList==null||cartList.size()==0){
            request.setAttribute("msg","购物车为空，请选择要购买的商品");
            return "/message.jsp";
        }
        System.out.println(cartList.toString());
        //放到域中
        request.setAttribute("cartList",cartList);
        return "/cart.jsp";
    }

    //method=addCartAjax
    public String addCartAjax(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
        User user = (User) request.getSession().getAttribute("user");
        if(user==null){
            return null;
        }
        //获取数据
        String goodsId = request.getParameter("goodsId");
        String number = request.getParameter("number");
        int num=1;
        if (!StringUtils.isEmpty(number)){
            try {
                num=Integer.parseInt(number);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        CartService cartService = new CartServiceImpl();
        Cart cart = cartService.findByUidAndPid(user.getId(), Integer.parseInt(goodsId));
        //根据num
        try {
            if(num==1||num==-1){
                //修改
                //查询商品
                GoodsService goodsService = new GoodsServiceImpl();
                Goods goods = goodsService.findById(Integer.parseInt(goodsId));
                if (cart!=null&&goods!=null){
                    cart.setNum(cart.getNum()+num);
                    cart.setMoney(goods.getPrice().multiply(new BigDecimal(cart.getNum())));
                    //重新绑定线程
                    cartService = new CartServiceImpl();
                    cartService.update(cart);
                }
            }else if(num==0){
                //删除
                cartService = new CartServiceImpl();
                cartService.delete(user.getId(),Integer.parseInt(goodsId));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //clearCartAjax
    public String clearCartAjax(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
        User user = (User) request.getSession().getAttribute("user");
        if(user==null){
            return null;
        }
        CartService cartService =new CartServiceImpl();
        try {
            cartService.deleteByUid(user.getId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
