package com.cxs.dao;

import com.cxs.entity.User;
import com.cxs.util.MyBatisUtils;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserDaoTest {

    @Test
    public void selectByUsernameAndPassword() {
        UserDao userDao= MyBatisUtils.getMapper(UserDao.class);
        User user = userDao.selectByUsernameAndPassword("zhangsan", "e10adc3949ba59abbe56e057f20f883e");
        System.out.println(user);
        MyBatisUtils.closeSession();
        Assert.assertNotNull(user);
    }

    @Test
    public void insertUser() {
//        UserDao userDao= MyBatisUtils.getMapper(UserDao.class);
//        User user=new User(0,"tangsan","123456","123@qq.com","男",1,"");
//        int count = userDao.insertUser(user);
//        MyBatisUtils.commit();
//        System.out.println(count);
    }

    @Test
    public void selectByUsername() {
    }
}