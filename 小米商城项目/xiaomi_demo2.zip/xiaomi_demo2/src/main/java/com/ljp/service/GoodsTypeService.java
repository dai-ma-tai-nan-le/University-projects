package com.ljp.service;

import com.ljp.entity.GoodsType;

import java.util.List;

public interface GoodsTypeService {
    List<GoodsType> findAll();
}
