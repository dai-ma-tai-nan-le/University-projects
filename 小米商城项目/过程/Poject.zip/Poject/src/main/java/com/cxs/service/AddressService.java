package com.cxs.service;

import com.cxs.entity.Address;

import java.util.List;

/**
 * <p>Project:poject01 - AddressServicr
 * <p>powered by 作者名 On 2022-10-28 11:41:38
 *
 * @author 作者名
 * @version 1.0
 * @since 1.8
 */
public interface AddressService {
    List<Address> findByUid(int uid);

    void addAddress(Address address);

    void deleteById(int aid);

    void update(Address address);

    void defaultAddress(int uid, int aid);
}
