package com.cxs.controller;

import com.cxs.entity.Address;
import com.cxs.entity.Cart;
import com.cxs.entity.User;
import com.cxs.service.AddressService;
import com.cxs.service.CartService;
import com.cxs.service.ipml.AddressServiceImpl;
import com.cxs.service.ipml.CartServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "OrderServlet",urlPatterns = "/orderservlet")
public class OrderServlet extends BaseServlet{
    //订单预览
    public String getOrderView(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        if(user==null){
            return "redirect:/login.jsp";
        }
        //获取购物车信息
        CartService cartService=new CartServiceImpl();
        List<Cart> cartList = cartService.findByUid(user.getId());
        if(cartList==null||cartList.size()==0){
            request.setAttribute("msg","购物车为空");
            return "/message.jsp";
        }
        //获取收货地址
        AddressService addressServicr = new AddressServiceImpl();
        List<Address> addresses = addressServicr.findByUid(user.getId());

        //放入域中
        request.setAttribute("cartList",cartList);
        request.setAttribute("addList",addresses);

        return "/order.jsp";
    }
}
