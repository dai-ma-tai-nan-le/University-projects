package com.cxs.controller;

import cn.dsna.util.images.ValidateCode;
import com.cxs.entity.Address;
import com.cxs.entity.User;
import com.cxs.service.AddressService;
import com.cxs.service.ipml.AddressServiceImpl;
import com.cxs.service.ipml.UserServiceIpml;
import com.cxs.service.UserService;
import com.cxs.util.Base64Utils;
import com.cxs.util.StringUtils;

import javax.imageio.ImageIO;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "UserServlet", urlPatterns = "/userservlet")
public class UserServlet extends BaseServlet {
    //用户注册
    public String regist(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取数据
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        String repassword=request.getParameter("repassword");
        String email=request.getParameter("email");
        String gender=request.getParameter("gender");
        //回显
        request.setAttribute("username",username);
        request.setAttribute("password",password);
        request.setAttribute("repassword",repassword);
        request.setAttribute("email",email);
        request.setAttribute("gender",gender);
        //2检验
        //非空检验
        if(StringUtils.isEmpty(username)){
            request.setAttribute("msg","用户名不能为空");
            return "/register.jsp";
        }
        if(StringUtils.isEmpty(password)){
            request.setAttribute("msg","密码不能为空");
            return "/register.jsp";
        }
        if(!password.equals(repassword)){
            request.setAttribute("msg","两次密码不一致");
            return "/register.jsp";
        }
        if(StringUtils.isEmpty(email)){
            request.setAttribute("msg","邮箱不能为空");
            return "/register.jsp";
        }
        //格式检验
        String reg="^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$";
        if(!email.matches(reg)){
            request.setAttribute("msg","邮箱格式不正确");
            return "/register.jsp";
        }
        //3创建业务对象
        UserService userService=new UserServiceIpml();
        //4调用方法
        try{
            User user = new User(0,username,password,email,gender,0,1,"");
            userService.regist(user);
            return "/registerSuccess.jsp";
        }catch (Exception e){
            e.printStackTrace();
            request.setAttribute("msg","注册失败:"+e.getMessage());
            return "/register.jsp";
        }
    }
    //用户登录
    public String login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //接受数据
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        String code=request.getParameter("code");
        String auto=request.getParameter("auto");
        //校验
        //非空校验
        if(StringUtils.isEmpty(username)){
            request.setAttribute("msg","用户名不能为空");
            return "/login.jsp";
        }
        if(StringUtils.isEmpty(password)){
            request.setAttribute("msg","密码不能为空");
            return "/login.jsp";
        }
        if(StringUtils.isEmpty(code)){
            request.setAttribute("msg","验证码不能为空");
            return "/login.jsp";
        }
        //验证码校验
        String serverCode = (String) request.getSession().getAttribute("serverCode");
        if(!code.equalsIgnoreCase(serverCode)){
            request.setAttribute("msg","验证码输入有误");
            return "/login.jsp";
        }
        //创建业务对象
        UserService userService = new UserServiceIpml();
        try {
            User user = userService.login(username,password);
            request.getSession().setAttribute("user",user);
            //判断是否勾选了auto
            if(auto!=null){
                System.out.println("勾选了auto");
                //Base64编码
                String userinfo=username+"#"+password;
                userinfo= Base64Utils.encode(userinfo);
                Cookie cookie=new Cookie("userinfo", userinfo);
                cookie.setMaxAge(60*60*24*14);
                response.addCookie(cookie);
            }
            return "redirect:/index.jsp";
            //重定向到首页
            //response.sendRedirect("index.jsp");
            //return "redirect:/index.jsp";
        }catch (Exception e){
            e.printStackTrace();
            request.setAttribute("msg","登录失败"+e.getMessage());
            return "/login.jsp";
        }

    }
    //检查用户名是否存在
    public String checkUserName(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
        String username = request.getParameter("username");
        if(StringUtils.isEmpty(username)){
            response.getWriter().write("1");
            return null;
        }
        //创建业务对象
        UserService userService=new UserServiceIpml();
        boolean b=userService.checkUserName(username);
        if(b){
            response.getWriter().write("1");
        }else{
            response.getWriter().write("0");
        }
        return null;
    }

    //返回验证码方法
    public String code(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException{
        //图片的高度100，图片的宽度30，验证字符个数4 ，干扰线 20
        ValidateCode validateCode=new ValidateCode(100, 30, 4,20);
        String code = validateCode.getCode();
        System.out.println(code);
        request.getSession().setAttribute("serverCode", code);
        //因为ImageIO默认是使用缓存目录，可以通过ImageIO.setUseCache(false)来设置，更改缓存策略，不使用文件目录缓存，使用内存缓存。
        ImageIO.setUseCache(false);
        validateCode.write(response.getOutputStream());
        return null;
    }

    //退出
    public String logOut(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
        HttpSession session = request.getSession();
        //1删除session中的数据
        session.removeAttribute("user");
        //2session失效
        session.invalidate();
        //3删除cookie
        Cookie cookie=new Cookie("userinfo", "");
        cookie.setMaxAge(0);
        response.addCookie(cookie);
        //4重定向
        return "redirect:/login.jsp";
    }

    //添加收货地址
    public String addAddress(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
        User user = (User) request.getSession().getAttribute("user");
        if(user==null){
            return null;
        }
        //获取信息
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String detail = request.getParameter("detail");
        if(StringUtils.isEmpty(name)){
            return null;
        }
        if(StringUtils.isEmpty(phone)){
            return null;
        }
        if(StringUtils.isEmpty(detail)){
            return null;
        }
        System.out.println(name+"..."+phone+"..."+detail);
        Address address = new Address(0,detail,name,phone, user.getId(),0);
        AddressService addressService = new AddressServiceImpl();
        try {
            addressService.addAddress(address);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //获取收货地址
    public String getAddress(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
        User user = (User) request.getSession().getAttribute("user");
        if(user==null){
            return "redirect:/login.jsp";
        }
        try {
            AddressService addressService = new AddressServiceImpl();
            List<Address> addList = addressService.findByUid(user.getId());
            request.setAttribute("addList",addList);
            return  "/self_info.jsp";
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("msg","获取收货地址失败");
            return "/message.jsp";
        }
    }

    //删除收货地址
    public String deleteAddress(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
        User user = (User) request.getSession().getAttribute("user");
        if(user==null){
            return "redirect:/login.jsp";
        }
        String id = request.getParameter("id");
        if (StringUtils.isEmpty(id)){
            request.setAttribute("msg","删除收货地址失败");
            return "/message.jsp";
        }
        try {
            AddressService addressService = new AddressServiceImpl();
            addressService.deleteById(Integer.parseInt(id));
            return "redirect:/userservlet?method=getAddress";
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("msg","删除收货地址失败,收货地址可能已经被使用");
            return "/message.jsp";
        }
    }

    //修改收货地址
    public String updateAddress(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
        User user = (User) request.getSession().getAttribute("user");
        if(user==null){
            return "redirect:/login.jsp";
        }
        //获取参数
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String detail = request.getParameter("detail");
        String level = request.getParameter("level");
        //校验

        //封装成对象
        try {
            Address address = new Address(Integer.parseInt(id),detail,name,phone, user.getId(), Integer.parseInt(level));
            AddressService addressService = new AddressServiceImpl();
            addressService.update(address);
            return "redirect:/userservlet?method=getAddress";
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("msg","修改收货地址失败");
            return "/message.jsp";
        }
    }

    //设置默认地址
    public String defaultAddress(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
        User user = (User) request.getSession().getAttribute("user");
        if(user==null){
            return "redirect:/login.jsp";
        }
        //获取参数
        try {
            String id = request.getParameter("id");
            AddressService addressService = new AddressServiceImpl();
            addressService.defaultAddress(user.getId(),Integer.parseInt(id));
            return "redirect:/userservlet?method=getAddress";
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("msg","设置默认收货地址失败");
            return "/message.jsp";
        }
    }

}
