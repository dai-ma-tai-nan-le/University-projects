package com.cxs.dao;

import com.cxs.entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface UserDao {
    @Select("select * from tb_user where username=#{username} and password=#{password}")
    User selectByUsernameAndPassword(@Param("username") String username,@Param("password") String password);
    @Insert("insert into tb_user values(null,#{username},#{password},#{email},#{gender},#{flag},#{role},#{code})")
    int insertUser(User user);
    @Select("select *from tb_user where username=#{username}")
    User selectByUserName(@Param("username") String username);
}
