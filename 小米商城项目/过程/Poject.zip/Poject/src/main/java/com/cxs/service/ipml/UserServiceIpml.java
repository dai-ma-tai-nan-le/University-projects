package com.cxs.service.ipml;

import com.cxs.dao.UserDao;
import com.cxs.entity.User;
import com.cxs.service.UserService;
import com.cxs.util.EmailUtils;
import com.cxs.util.Md5Utils;
import com.cxs.util.MyBatisUtils;

public class UserServiceIpml implements UserService {
    UserDao userDao= MyBatisUtils.getMapper(UserDao.class);

    @Override
    public void regist(User user) {
        //密码加密
        user.setPassword(Md5Utils.md5(user.getPassword()));
        //判断用户名是否可用
        User u = userDao.selectByUserName(user.getUsername());
        if(u!=null){
            throw new RuntimeException("用户名已存在");
        }
        userDao.insertUser(user);
        MyBatisUtils.commit();
        //发送邮件
        EmailUtils.sendEmail(user);
    }

    @Override
    public boolean checkUserName(String username) {
        User user=userDao.selectByUserName(username);
        MyBatisUtils.closeSession();
        if(user!=null){
            return true;
        }
        return false;
    }

    @Override
    public User login(String username, String password) {
        password=Md5Utils.md5(password);
        User user=userDao.selectByUsernameAndPassword(username,password);
        MyBatisUtils.closeSession();
        if(user==null){
            throw new RuntimeException("用户名或密码错误");
        }
        if(user.getFlag()!=1){
            throw new RuntimeException("账号未激活或异常");
        }
        return user;
    }
}
