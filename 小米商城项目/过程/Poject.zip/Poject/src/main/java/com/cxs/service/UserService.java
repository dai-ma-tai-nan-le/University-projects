package com.cxs.service;

import com.cxs.entity.Address;
import com.cxs.entity.User;

public interface UserService {
    public void regist(User user);
    boolean checkUserName(String username);

    User login(String username, String password);

}
