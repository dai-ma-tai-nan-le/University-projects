package commander;

public enum commanderwepon implements selectcommandworks
{
	rocket("���Ͳ",1),firepro("����ǹ",2),N_b("�˵�ͷ",3),navy("ʮ��½��",4),airman("ʮ�򺣾�",5),army("ʮ��վ�",6);
	String name;
	int num;
	static private String weapon;
	static private int weapnum;
	commanderwepon(String weaname,int i)
	{
		this.name=weaname;
		this.num=i;
	}
	
	public static String getcommanderwepon(int i) 
	{
		for(commanderwepon c: values()) 
		{
			if(i==c.num) 
			{
				commanderwepon.setWeapon(c.name);
				//��c.name���뾲̬��setWeapon������
				
			}
		}
		return commanderwepon.getWeapon();
	}
	
	public static String getWeapon() {
		return weapon;
	}
	public static void setWeapon(String weapon) {
		commanderwepon.weapon = weapon;
	}
	public static int getWeapnum() {
		return weapnum;
	}
	public static void setWeapnum(int weapnum) {
		commanderwepon.weapnum = weapnum;
	}
	
}
