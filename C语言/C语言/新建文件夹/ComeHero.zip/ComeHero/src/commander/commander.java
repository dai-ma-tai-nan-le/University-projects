package commander;
public enum commander
{
	red("��ɫ", 1), green("��ɫ", 2), blank("��ɫ", 3), yellow("��ɫ", 4);
	int num;
	String color;
	private static String name;
	private static String sex;
	private static String cap;
	commander(String c, int i) {
		num=i;
		color=c;
	}
	public static String getcommandercapcolor(int i) 
	{
		for(commander c: values()) 
		{
			if(i==c.num) 
			{
				commander.setCap(c.color);
				//��c.color���뾲̬��setcap������
			}
		}
		return commander.getCap();
	}
	public static String getName() {
		return name;
	}
	public static void setName(String name) {
		commander.name = name;
	}
	public static String getSex() {
		return sex;
	}
	public static void setSex(String sex) {
		commander.sex = sex;
	}
	public static String getCap() {
		return cap;
	}
	public static void setCap(String cap) {
		commander.cap = cap;
	}
}
//����˾��Ķ�ֻ��������һ�� ���þ�̬����