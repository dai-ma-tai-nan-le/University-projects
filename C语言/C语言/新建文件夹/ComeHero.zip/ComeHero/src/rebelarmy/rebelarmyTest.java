package rebelarmy;
public class rebelarmyTest 
{
	public rebelarmyTest()
	{
		
		
		
	}
	public static void main(String[] ager) 
	{
		//new rebelarmyTest();
	}
	
}
