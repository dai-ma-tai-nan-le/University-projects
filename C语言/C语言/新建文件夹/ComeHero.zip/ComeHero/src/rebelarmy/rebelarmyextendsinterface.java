package rebelarmy;
public interface rebelarmyextendsinterface extends rebelarmyinterface 
{
	public static void  createrebelarmyextend(int select){};
}