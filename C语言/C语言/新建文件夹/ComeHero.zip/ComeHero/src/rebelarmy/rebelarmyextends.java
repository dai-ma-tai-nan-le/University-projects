package rebelarmy;
public class rebelarmyextends implements rebelarmyextendsinterface
{
	static double attack;
	static double def;
	static int blood;
	static int states;//���������
	rebelarmyextends()
	{
		//��ʼ��
		//System.out.println("��ʼ���ɹ�");
		rebelarmyextends.setattack(1000);
		rebelarmyextends.setblood(400);
		//��Ѫ��Ϊ����Ѫ��������
		rebelarmyextends.setdef(1000);
	}
	public static void rebelarmyextendsStates(int states)
	{
		rebelarmyextends.setstates(states);
		//����������빹�췽����
		rebelarmyextends.rebelarmyextendsChanage();
	}
	public static void rebelarmyextendsChanage()
	{
		//���ݹ��췽����getstates()ѡ�������Ѿ�����
		if(rebelarmyextends.getstates()==1) 
		{
			rebelarmyextends.setblood((int) (rebelarmyextends .getblood()*0.5));//1/2Ѫ��
			rebelarmyextends.setattack(rebelarmyextends .getattack()*0.5);//1/2
			rebelarmyextends.setdef(rebelarmyextends.getdef()*0.5);//1/2
		}
		if(rebelarmyextends.getstates()==2) 
		{
			rebelarmyextends.setblood((int) (rebelarmyextends .getblood()));//1
			rebelarmyextends.setattack(rebelarmyextends .getattack());//1
			rebelarmyextends.setdef(rebelarmyextends.getdef());//1
		}
		if(rebelarmyextends.getstates()==3) 
		{
			rebelarmyextends.setblood((int) (rebelarmyextends .getblood()*2));//2
			rebelarmyextends.setattack(rebelarmyextends .getattack()*2);//2
			rebelarmyextends.setdef(rebelarmyextends.getdef()*2);//2
		}
	}
	//����
	public static void setattack(double attack) 
	{
		rebelarmyextends.attack=attack;
	}
	public static double getattack() 
	{
		return rebelarmyextends.attack;
	}
	//����
	public static void setdef(double def) 
	{
		rebelarmyextends.def=def;
	}
	public static double getdef() 
	{
		return rebelarmyextends.def;
	}
	//Ѫ��
	public static void setblood(int  blood) 
	{
		rebelarmyextends.blood=blood;
	}
	public static double getblood() 
	{
		return rebelarmyextends.blood;
	}
	//״̬
	public static void setstates(int  states) 
	{
		rebelarmyextends.states=states;
	}
	public static double getstates() 
	{
		return rebelarmyextends.states;
	}
}
