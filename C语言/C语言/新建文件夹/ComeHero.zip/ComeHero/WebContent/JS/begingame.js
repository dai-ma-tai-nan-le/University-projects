function begingame()
{
	location.href='SelectHero.jsp';
}
//选择英雄的扮演者（种类）
function SetHeroActor(e)
{
	var xmlhttp;
	if(window.XMLHttpRequest)
	{
		xmlhttp=new XMLHttpRequest();
	}
	else{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	if(xmlhttp){
		
		xmlhttp.open("POST","selectHeroActorselvert",true);
		//System.out.println("进入selvert");
		xmlhttp.onreadystatechange = function(){
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
			{
				if(xmlhttp.responseText=="HKsetHeroNoOK")
				{
					location.href='HKHeroActer.jsp';
					//(1)如果传递的参数合适无误，进入选择英雄角色jsp	
				}
				if(xmlhttp.responseText=="DZsetHeroNoOK")
				{
					location.href='DZHeroActer.jsp';
					//(2)如果传递的参数合适无误，进入选择英雄角色jsp	
				}
				if(xmlhttp.responseText=="LSsetHeroNoOK")
				{
					location.href='LSHeroActer.jsp';
					//(3)如果传递的参数合适无误，进入选择英雄角色jsp	
				}
				if(xmlhttp.responseText=="GTXsetHeroNoOK")
				{
					location.href='GTXHeroActer.jsp';
					//(4)如果传递的参数合适无误，进入选择英雄角色jsp	
				}
				if(xmlhttp.responseText=="YYsetHeroNoOK")
				{
					location.href='YYHeroActer.jsp';
					//(5)如果传递的参数合适无误，进入选择英雄角色jsp	
				}
				if(xmlhttp.responseText=="HGFsetHeroNoOK")
				{
					location.href='HGFHeroActer.jsp';
					//(6)如果传递的参数合适无误，进入选择英雄角色jsp	
				}
				else{
					out.print("IE输入英雄基本信息有误！");
					System.out.println("contro输入英雄基本信息有误！ ");
				}
			}
		}
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xmlhttp.send("herono="+document.getElementById("herono").value);
		//传递多个参数用键值对来实现,或者采用&连接键值+连接参数()
		
	}
}
//这个是传递英雄的基本信息（（名，性别，宝石）
function selectHeroInfo()
{
	var xmlhttp;
	if(window.XMLHttpRequest)
	{
		xmlhttp=new XMLHttpRequest();
	}
	else{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	if(xmlhttp){
		
		xmlhttp.open("POST","selectHeroinfoselvert",true);
		//System.out.println("进入selvert");
		xmlhttp.onreadystatechange = function(){
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
			{
				if(xmlhttp.responseText=="setHeroNameSexGemOK")
				{
					location.href='SelectHeroActer.jsp';
					//如果传递的参数合适无误，进入选择英雄角色准备jsp
					
				}else{
					out.print("IE输入英雄选择有误！");
					System.out.println("contro输入英雄选择有误！ ");
				}
			}
		}
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xmlhttp.send("heroname="+document.getElementById("heroname").value+"&herosex="+document.getElementById("herosex").value+"&herogem="+document.getElementById("herogem").value);
		
		//传递多个参数用键值对来实现,或者采用&连接键值+连接参数()
		
	}
}
//这个是根据所选项调用英雄能力计算方法
function CheckHeroPower()
{
	var xmlhttp;
	if(window.XMLHttpRequest)
	{
		xmlhttp=new XMLHttpRequest();
	}
	else{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	if(xmlhttp){
		
		xmlhttp.open("POST","GetHeroinfoselvert",true);
		//System.out.println("进入selvert");
		xmlhttp.onreadystatechange = function(){
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
			{
				if(xmlhttp.responseText=="GetHeroInfoOK")
				{
					GetHeroInfo();
					out.print("IE输出英雄结果ok！");
					System.out.println("contro输出英雄结果ok！ ");
					//将英雄的能力展现出来
					
				}else{
					out.print("IE输出英雄结果有误！");
					System.out.println("contro输出英雄结果有误！ ");
				}
			}
		}
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xmlhttp.send();
	}
}

function GetHeroInfo()
{
	document.getElementById("AboutHero").style.display = 'block';
}
