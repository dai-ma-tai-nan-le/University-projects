function selectmap()
{
	//系统选择地图
	var xmlhttp;
	if(window.XMLHttpRequest)
	{
		xmlhttp=new XMLHttpRequest();
	}
	else{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	if(xmlhttp){
		
		xmlhttp.open("POST","SelectWarMapselvert",true);
		//System.out.println("进入selvert");
		xmlhttp.onreadystatechange = function(){
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
			{
				if(xmlhttp.responseText=="GetWarMapOK")
				{
					out.print("IE输出战斗地图ok！");
					System.out.println("contro战斗输出地图ok！ ");
					//将英雄的能力展现出来
					
				}else{
					out.print("IE输出战斗地图有误！");
					System.out.println("contro战斗地图有误！ ");
				}
			}
		}
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xmlhttp.send();
	}
}
//系统选择敌人种类以及敌人等级
function CheckrebelarmyPower()
{
	//系统选择地图
	var xmlhttp;
	if(window.XMLHttpRequest)
	{
		xmlhttp=new XMLHttpRequest();
	}
	else{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	if(xmlhttp){
		
		xmlhttp.open("POST","CheckrebelarmyPowerselvert",true);
		//System.out.println("进入selvert");
		xmlhttp.onreadystatechange = function(){
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
			{
				if(xmlhttp.responseText=="GetrebelarmyPowerOK")
				{
					out.print("IE输出敌人信息ok！");
					System.out.println("contro输出敌人信息ok！ ");
					//将英雄的能力展现出来
					
				}else{
					out.print("IE输出敌人信息有误！");
					System.out.println("contro敌人信息有误！ ");
				}
			}
		}
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xmlhttp.send();
	}
}
