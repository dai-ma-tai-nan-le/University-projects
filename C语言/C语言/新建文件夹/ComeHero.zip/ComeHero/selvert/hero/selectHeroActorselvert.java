package hero;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import commander.commanderweponfactory;
import commander.storecommander;

@WebServlet("/selectHeroActorselvert")
public class selectHeroActorselvert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public selectHeroActorselvert() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		System.out.println("________________________");
		System.out.println("ѡ��Ӣ����Ϣģ�鿪ʼ��");
		response.setContentType("text/html;utf-8");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		//String path="SelectHeroActor.jsp";
		PrintWriter out = response.getWriter();
		String herono=request.getParameter("herono");
		
		
		System.out.println("һ������"+"no="+herono);
		
		try {
			new commanderweponfactory(Integer.parseInt(herono)) ;
			
			//�ǵ�Ҫ���л�
			//��hero�ı��Javaʵ������
			//��ҳ���ȡ��������ʵ����
			if(storecommander.getcommander_weapon()!=null)
				//�ж�storecommander�Ƿ��ȡ���ʵĲ���
			{
				if(storecommander.getcommander_weapon().equals("���Ͳ")) 
				{
					out.print("HKsetHeroNoOK");
					//ѡ��ƿ�
				}
				if(storecommander.getcommander_weapon().equals("����ǹ")) 
				{
					out.print("DZsetHeroNoOK");
					//�ӳ�
				}
				if(storecommander.getcommander_weapon().equals("�˵�ͷ")) 
				{
					out.print("LSsetHeroNoOK");
					//����
				}
				if(storecommander.getcommander_weapon().equals("ʮ��½��")) 
				{
					out.print("GTXsetHeroNoOK");
					//������
				}
				if(storecommander.getcommander_weapon().equals("ʮ�򺣾�")) 
				{
					out.print("YYsetHeroNoOK");
					//ӥ��
				}
				if(storecommander.getcommander_weapon().equals("ʮ��վ�")) 
				{
					out.print("HGFsetHeroNoOK");
					//�ڹѸ�
				}
			}
			else
			{
				out.print("heronoerrors");
			}
			
			System.out.println("Ӣ�۱��"+storecommander.getcommander_weapnum());
			System.out.println("Ӣ������"+storecommander.getcommander_weapon());
			
			
			System.out.println("selvertת��������");
		} 
		catch (Exception e)
		{
			e.printStackTrace();
			System.out.println("��ǰҳ�����,��ʾ����Ӣ����Ϣ");
			
		}
		out.flush();
		out.close();
	}
}
